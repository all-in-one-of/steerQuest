#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <fstream>
using namespace std;

int main () {
  srand(time(NULL));
  float value=0.0;
  time_t t = 0;
  int x_coord, y_coord;
  ofstream myfile;
  myfile.open ("example.txt");
  for (t=0; t<100;t++)
  for (int sheep = 0; sheep < 100; ++sheep) {
                             x_coord = rand()%100; 
                             y_coord = rand()%100;
                             myfile << t << " " << sheep << " " << x_coord << " " << y_coord<<"\n";
                         }
  myfile.close();
  return 0;
}