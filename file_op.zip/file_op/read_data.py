#!/usr/bin/python

f = open("example.txt","r")
contents = f.read()
f.close()

for row in contents.split("\n"):
    print row